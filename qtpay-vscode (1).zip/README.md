
# Bill Splitter

โปรแกรมสำหรับแบ่งบิลอาหารหรือค่าใช้จ่ายระหว่างเพื่อน พร้อมสร้าง QR Code PromptPay สำหรับการชำระเงิน

## คุณสมบัติ

- บันทึกรายการอาหารและราคา
- คำนวณการแบ่งจ่ายตามจำนวนคนที่รับประทานอาหารแต่ละรายการ
- คำนวณภาษีมูลค่าเพิ่ม (VAT)
- แสดงและบันทึก QR Code PromptPay
- บันทึกประวัติการแบ่งบิล

## ความต้องการระบบ

- C++17 หรือสูงกว่า
- SFML library
- libcurl

## การติดตั้ง

### วิธีติดตั้ง SFML และ libcurl บน Ubuntu/Debian:

```bash
sudo apt-get update
sudo apt-get install libsfml-dev libcurl4-openssl-dev
```

### วิธีติดตั้ง SFML และ libcurl บน Windows (ด้วย MSYS2):

```bash
pacman -S mingw-w64-x86_64-sfml mingw-w64-x86_64-curl
```

## การคอมไพล์

```bash
make
```

หรือ

```bash
g++ -std=c++17 main.cpp -o main -lcurl -lsfml-graphics -lsfml-window -lsfml-system
```

## การใช้งาน

```bash
./main
```

## การใช้งานกับ VS Code

โปรเจคนี้มีการกำหนดค่า VS Code ไว้แล้ว:
1. กด F5 เพื่อรันโปรแกรมในโหมดดีบัก
2. Ctrl+Shift+B เพื่อคอมไพล์โปรแกรม
